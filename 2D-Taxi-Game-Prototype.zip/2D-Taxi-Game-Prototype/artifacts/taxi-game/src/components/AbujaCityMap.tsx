import { memo } from 'react';
import type { TaxiStop } from '@/game/routes';
import type { Direction, TaxiGameState, TripPhase } from '@/game/types';
import { GAME_HEIGHT, GAME_WIDTH, ROAD_X, ROAD_Y } from '@/game/types';

type LandmarkKind = 'lake' | 'terminal' | 'embassy' | 'market' | 'mosque' | 'assembly' | 'park' | 'rock' | 'district';

type District = {
  name: string;
  landmark: string;
  kind: LandmarkKind;
  tint: string;
};

const districts: District[][] = [
  [
    { name: 'JABI', landmark: 'JABI LAKE', kind: 'lake', tint: '#d4e2cb' },
    { name: 'UTAKO', landmark: 'TRANSIT TERMINAL', kind: 'terminal', tint: '#e5d6b2' },
    { name: 'MAITAMA', landmark: 'DIPLOMATIC QUARTER', kind: 'embassy', tint: '#d8e0ca' },
    { name: 'WUSE', landmark: 'WUSE MARKET', kind: 'market', tint: '#ead8ae' },
  ],
  [
    { name: 'JABI', landmark: 'RESIDENTIAL DISTRICT', kind: 'district', tint: '#e8dabb' },
    { name: 'UTAKO', landmark: 'BUSINESS DISTRICT', kind: 'district', tint: '#d9e0ca' },
    { name: 'MAITAMA', landmark: 'AMINU KANO CRESCENT', kind: 'embassy', tint: '#e9d8b4' },
    { name: 'WUSE 2', landmark: 'CITY CENTRE', kind: 'market', tint: '#d5e0ce' },
  ],
  [
    { name: 'CENTRAL AREA', landmark: 'NATIONAL MOSQUE', kind: 'mosque', tint: '#dfe5cd' },
    { name: 'CENTRAL AREA', landmark: 'NATIONAL ASSEMBLY', kind: 'assembly', tint: '#e9d8b8' },
    { name: 'CENTRAL AREA', landmark: 'MILLENNIUM PARK', kind: 'park', tint: '#d2e0c5' },
    { name: 'CENTRAL AREA', landmark: 'CIVIC DISTRICT', kind: 'district', tint: '#e6d9bd' },
  ],
  [
    { name: 'GARKI', landmark: 'AREA 11', kind: 'district', tint: '#e5d5b3' },
    { name: 'GARKI', landmark: 'GARKI MODEL MARKET', kind: 'market', tint: '#d8e1c9' },
    { name: 'ASOKORO', landmark: 'PRESIDENTIAL DISTRICT', kind: 'embassy', tint: '#e7d8b9' },
    { name: 'ASOKORO', landmark: 'ASO ROCK', kind: 'rock', tint: '#d5dfc8' },
  ],
];

function Tree({ x, y, size = 1 }: { x: number; y: number; size?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${size})`}>
      <ellipse cx="0" cy="6" rx="10" ry="4" fill="#87916c" opacity=".25" />
      <rect x="-2" y="-4" width="4" height="12" rx="1" fill="#8a6944" />
      <circle cy="-10" r="9" fill="#5e8159" />
      <circle cx="-5" cy="-7" r="5" fill="#789469" />
      <circle cx="5" cy="-7" r="5" fill="#6e8b60" />
    </g>
  );
}

function Landmark({ kind, x, y }: { kind: LandmarkKind; x: number; y: number }) {
  if (kind === 'lake') {
    return (
      <g transform={`translate(${x} ${y})`}>
        <path d="M-71 15c13-20 27-9 40-17 17-11 24-3 39-12 21-12 43-2 65 13v28H-71Z" fill="#83b5ac" />
        <path d="M-67 13c13-17 28-8 41-16 17-10 25-2 40-11 20-12 42-1 58 10M-60 22c19-12 27-5 44-12 21-8 33 0 51-9 13-6 25-1 35 6" fill="none" stroke="#d1e7d7" strokeWidth="2" opacity=".8" />
        <path d="M-79 33h156" stroke="#baaa82" strokeWidth="5" strokeLinecap="round" />
        <path d="M-22 26v11m7-11v11m7-11v11" stroke="#826d4c" strokeWidth="2" />
        <Tree x={-72} y={-2} size={.75} />
        <Tree x={69} y={3} size={.8} />
        <Tree x={46} y={-16} size={.6} />
      </g>
    );
  }

  if (kind === 'terminal') {
    return (
      <g transform={`translate(${x} ${y})`}>
        <path d="M-77-10 0-30 77-10v8h-154z" fill="#176a46" stroke="#d8b75f" strokeWidth="2" />
        <path d="M-62-8v35m31-35v35M0-8v35m31-35v35m31-35v35" stroke="#b99e68" strokeWidth="3" />
        <rect x="-72" y="26" width="144" height="9" rx="2" fill="#c1aa7b" />
        <g transform="translate(-29 11)">
          <rect x="-17" y="-12" width="35" height="18" rx="5" fill="#e5b84e" stroke="#52665c" strokeWidth="1.5" />
          <rect x="-11" y="-9" width="20" height="7" rx="2" fill="#b7d0c2" />
          <circle cx="-9" cy="7" r="3" fill="#36483e" /><circle cx="10" cy="7" r="3" fill="#36483e" />
        </g>
        <g transform="translate(33 13)">
          <rect x="-16" y="-10" width="33" height="16" rx="5" fill="#f4eee0" stroke="#52665c" strokeWidth="1.5" />
          <rect x="-10" y="-7" width="18" height="6" rx="2" fill="#a8c5b6" />
          <circle cx="-8" cy="7" r="3" fill="#36483e" /><circle cx="9" cy="7" r="3" fill="#36483e" />
        </g>
        <Tree x={-83} y={4} size={.65} />
        <Tree x={84} y={2} size={.65} />
      </g>
    );
  }

  if (kind === 'embassy') {
    return (
      <g transform={`translate(${x} ${y})`}>
        <path d="M-77 27h154" stroke="#a89a72" strokeWidth="3" />
        <rect x="-57" y="-6" width="48" height="33" rx="2" fill="#f4ead3" stroke="#9c8c68" strokeWidth="1.5" />
        <path d="M-62-6h58l-8-11h-42z" fill="#956d49" />
        <rect x="8" y="-13" width="47" height="40" rx="2" fill="#e8dec6" stroke="#9c8c68" strokeWidth="1.5" />
        <path d="M3-13h57l-9-11H12z" fill="#6d805f" />
        <rect x="-45" y="4" width="11" height="13" fill="#a6c3b4" />
        <rect x="-25" y="4" width="11" height="13" fill="#a6c3b4" />
        <rect x="19" y="-3" width="10" height="12" fill="#a6c3b4" />
        <rect x="37" y="-3" width="10" height="12" fill="#a6c3b4" />
        <path d="M-66 28h132" stroke="#567950" strokeWidth="5" strokeDasharray="2 8" />
        <Tree x={-78} y={8} size={.65} /><Tree x={76} y={5} size={.7} />
      </g>
    );
  }

  if (kind === 'market') {
    const awnings = ['#b84b37', '#e3b44d', '#176a46', '#cf7840'];
    return (
      <g transform={`translate(${x} ${y})`}>
        <rect x="-72" y="-3" width="144" height="31" rx="3" fill="#f2e7d0" stroke="#9e8b67" strokeWidth="1.5" />
        <path d="M-77-4h154l-8-14H-69z" fill="#176a46" stroke="#9e8b67" strokeWidth="1.5" />
        {[-54, -18, 18, 54].map((dx, i) => (
          <g key={dx}>
            <path d={`M${dx - 17}-18h34v12h-34z`} fill={awnings[i]} />
            <path d={`M${dx - 6}-18h11v12h-11z`} fill="#fff3d7" opacity=".8" />
            <rect x={dx - 9} y="3" width="18" height="18" rx="2" fill="#a8c3b4" stroke="#79917f" />
          </g>
        ))}
        <Tree x={-81} y={7} size={.6} /><Tree x={83} y={5} size={.6} />
      </g>
    );
  }

  if (kind === 'mosque') {
    return (
      <g transform={`translate(${x} ${y})`}>
        <rect x="-49" y="-1" width="98" height="30" rx="3" fill="#f2ead7" stroke="#9b8e6e" strokeWidth="1.5" />
        <path d="M-32-2c0-39 64-39 64 0" fill="#477858" stroke="#315e47" strokeWidth="2" />
        <path d="M0-38v-18m-5 1 5-8 5 8" fill="none" stroke="#d5ae53" strokeWidth="2.5" strokeLinecap="round" />
        <rect x="-43" y="-34" width="7" height="32" rx="3" fill="#e3d3ae" />
        <rect x="36" y="-34" width="7" height="32" rx="3" fill="#e3d3ae" />
        <path d="M-11 29V14a11 11 0 0 1 22 0v15" fill="#8aa18a" />
        <Tree x={-68} y={16} size={.6} /><Tree x={67} y={16} size={.6} />
      </g>
    );
  }

  if (kind === 'assembly') {
    return (
      <g transform={`translate(${x} ${y})`}>
        <rect x="-68" y="1" width="136" height="29" rx="2" fill="#e6ddc8" stroke="#988b6b" strokeWidth="1.5" />
        <path d="M-74 2 0-21 74 2z" fill="#b49b69" stroke="#877950" strokeWidth="1.5" />
        <path d="M-28-18c0-30 56-30 56 0" fill="#597c5c" stroke="#426349" strokeWidth="1.5" />
        <path d="M-49 4v21m24-21v21M0 4v21m25-21v21m24-21v21" stroke="#b3a27b" strokeWidth="4" />
        <rect x="-8" y="11" width="16" height="19" fill="#a9c1ae" />
        <Tree x={-81} y={14} size={.6} /><Tree x={83} y={14} size={.6} />
      </g>
    );
  }

  if (kind === 'park') {
    return (
      <g transform={`translate(${x} ${y})`}>
        <path d="M-78 23c25-19 43-10 63-18 31-12 52-5 92-14" fill="none" stroke="#c2ad7a" strokeWidth="5" strokeLinecap="round" />
        <path d="M-75-14c32 9 50 2 69 11 31 14 52 11 83 3" fill="none" stroke="#e9e1c7" strokeWidth="3" />
        <Tree x={-59} y={-3} size={1.05} /><Tree x={-22} y={16} size={.8} />
        <Tree x={20} y={-12} size={1.15} /><Tree x={55} y={10} size={.9} />
        <circle cx="4" cy="24" r="7" fill="#c6a95b" />
      </g>
    );
  }

  if (kind === 'rock') {
    return (
      <g transform={`translate(${x} ${y})`}>
        <path d="M-78 29-55 3-39 11-15-22 2-2 18-31 37-8 51-17 78 29z" fill="#a98a5e" stroke="#806b4b" strokeWidth="2" />
        <path d="m-15-22 15 20 18-29 19 23" fill="none" stroke="#dcc38e" strokeWidth="2.5" opacity=".9" />
        <path d="M-80 30h160" stroke="#68815c" strokeWidth="7" />
        <Tree x={-70} y={17} size={.55} /><Tree x={69} y={16} size={.55} />
      </g>
    );
  }

  return (
    <g transform={`translate(${x} ${y})`}>
      <path d="M-73 26h146" stroke="#a99b75" strokeWidth="3" />
      <rect x="-64" y="-10" width="37" height="36" rx="3" fill="#eadfc5" stroke="#ab9a72" />
      <rect x="-19" y="-21" width="39" height="47" rx="3" fill="#e7ddc6" stroke="#ab9a72" />
      <rect x="27" y="-6" width="37" height="32" rx="3" fill="#f1e7cf" stroke="#ab9a72" />
      <rect x="-55" y="-3" width="10" height="11" fill="#a7c2b2" /><rect x="-11" y="-14" width="11" height="12" fill="#a7c2b2" />
      <rect x="2" y="-14" width="11" height="12" fill="#a7c2b2" /><rect x="36" y="1" width="10" height="11" fill="#a7c2b2" />
      <Tree x={-76} y={11} size={.6} /><Tree x={77} y={10} size={.65} />
      <path d="M-66-12h40M-21-24h43M27-9h38" stroke="#5f795a" strokeWidth="3" />
    </g>
  );
}

const CityBlocks = memo(function CityBlocks() {
  return (
    <g>
      <rect width={GAME_WIDTH} height={GAME_HEIGHT} fill="#d5ddc5" />
      <path d="M0 0h1280v76H0zM0 884h1280v76H0z" fill="#c5d2b4" opacity=".52" />
      {districts.flatMap((row, rowIndex) => row.map((district, columnIndex) => {
        const x = ROAD_X[columnIndex] + 43;
        const y = ROAD_Y[rowIndex] + 34;
        const w = ROAD_X[columnIndex + 1] - ROAD_X[columnIndex] - 86;
        const h = ROAD_Y[rowIndex + 1] - ROAD_Y[rowIndex] - 68;
        const centerX = x + w / 2;
        const centerY = y + h / 2 - 6;
        return (
          <g key={`${rowIndex}-${columnIndex}`}>
            <rect x={x} y={y} width={w} height={h} rx="13" fill={district.tint} stroke="#aeb493" strokeWidth="2" />
            <path d={`M${x + 8} ${y + h - 38}h${w - 16}`} stroke="#c3b894" strokeWidth="1" strokeDasharray="3 7" opacity=".8" />
            <Landmark kind={district.kind} x={centerX} y={centerY} />
            <text x={centerX} y={y + h - 23} textAnchor="middle" className="map-district-label">{district.name}</text>
            <text x={centerX} y={y + h - 8} textAnchor="middle" className="map-landmark-label">{district.landmark}</text>
          </g>
        );
      }))}
    </g>
  );
});

const RoadNetwork = memo(function RoadNetwork() {
  return (
    <g>
      {ROAD_X.map((x) => (
        <g key={`vertical-road-${x}`}>
          <rect x={x - 49} y="0" width="98" height={GAME_HEIGHT} fill="#b4a98c" opacity=".65" />
          <rect x={x - 43} y="0" width="86" height={GAME_HEIGHT} fill="#5d655f" />
          <path d={`M${x - 38} 0V${GAME_HEIGHT}M${x + 38} 0V${GAME_HEIGHT}`} stroke="#d3c7a2" strokeWidth="2" />
          <path d={`M${x - 25} 0V${GAME_HEIGHT}M${x + 25} 0V${GAME_HEIGHT}`} stroke="#e5dfc9" strokeWidth="2" strokeDasharray="14 18" opacity=".78" />
          <path d={`M${x} 0V${GAME_HEIGHT}`} stroke="#d7bc72" strokeWidth="2" strokeDasharray="12 16" opacity=".9" />
        </g>
      ))}
      {ROAD_Y.map((y) => (
        <g key={`horizontal-road-${y}`}>
          <rect x="0" y={y - 46} width={GAME_WIDTH} height="92" fill="#b4a98c" opacity=".65" />
          <rect x="0" y={y - 40} width={GAME_WIDTH} height="80" fill="#5d655f" />
          <path d={`M0 ${y - 35}H${GAME_WIDTH}M0 ${y + 35}H${GAME_WIDTH}`} stroke="#d3c7a2" strokeWidth="2" />
          <path d={`M0 ${y - 23}H${GAME_WIDTH}M0 ${y + 23}H${GAME_WIDTH}`} stroke="#e5dfc9" strokeWidth="2" strokeDasharray="14 18" opacity=".78" />
          <path d={`M0 ${y}H${GAME_WIDTH}`} stroke="#d7bc72" strokeWidth="2" strokeDasharray="12 16" opacity=".9" />
        </g>
      ))}
      {ROAD_X.flatMap((x, columnIndex) => ROAD_Y.map((y, rowIndex) => (
        <g key={`crossing-${columnIndex}-${rowIndex}`}>
          {[-1, 1].map((side) => (
            <g key={side} opacity=".8">
              {Array.from({ length: 4 }, (_, stripe) => (
                <rect key={`v-${stripe}`} x={x + side * 30 - 4} y={y - 26 + stripe * 14} width="8" height="8" rx="1" fill="#e9e2ce" />
              ))}
              {Array.from({ length: 4 }, (_, stripe) => (
                <rect key={`h-${stripe}`} x={x - 26 + stripe * 14} y={y + side * 28 - 4} width="8" height="8" rx="1" fill="#e9e2ce" />
              ))}
            </g>
          ))}
        </g>
      )))}
      <g className="map-road-sign" transform="translate(752 80)">
        <rect x="-84" y="-12" width="168" height="24" rx="5" fill="#176a46" stroke="#e5bc5c" strokeWidth="2" />
        <text x="0" y="4" textAnchor="middle">ABUJA · FCT</text>
      </g>
      <g className="map-road-sign" transform="translate(1080 682)">
        <rect x="-76" y="-12" width="152" height="24" rx="5" fill="#176a46" stroke="#e5bc5c" strokeWidth="2" />
        <text x="0" y="4" textAnchor="middle">GARKI DISTRICT</text>
      </g>
    </g>
  );
});

const TrafficLayer = memo(function TrafficLayer() {
  const cars = [
    { key: 'eastbound', path: 'M170 103 H1110', duration: '24s', begin: '-8s', fill: '#e7b649', rotate: 'auto' },
    { key: 'westbound', path: 'M1110 497 H170', duration: '29s', begin: '-19s', fill: '#dfede0', rotate: 'auto' },
    { key: 'southbound', path: 'M411 150 V814', duration: '21s', begin: '-12s', fill: '#bd6841', rotate: 'auto' },
    { key: 'northbound', path: 'M922 814 V150', duration: '26s', begin: '-5s', fill: '#d9eadf', rotate: 'auto' },
  ];
  return (
    <g aria-label="Moving city traffic">
      {cars.map((car) => (
        <g key={car.key} className="traffic-vehicle" opacity=".94">
          <rect x="-18" y="-9" width="36" height="18" rx="6" fill={car.fill} stroke="#26392f" strokeWidth="2" />
          <rect x="-9" y="-6" width="17" height="12" rx="3" fill="#a9c8b8" />
          <rect x="-15" y="-11" width="7" height="2.5" rx="1" fill="#f8eec8" />
          <rect x="9" y="8.5" width="6" height="2.5" rx="1" fill="#d45d40" />
          <animateMotion className="traffic-motion" dur={car.duration} begin={car.begin} repeatCount="indefinite" path={car.path} rotate={car.rotate} />
        </g>
      ))}
    </g>
  );
});

function TaxiMarker({ x, y, heading }: { x: number; y: number; heading: Direction }) {
  const rotation = { up: 0, right: 90, down: 180, left: 270 }[heading];
  return (
    <g transform={`translate(${x} ${y}) rotate(${rotation})`} data-testid="marker-taxi">
      <ellipse cx="0" cy="3" rx="23" ry="16" fill="#202b26" opacity=".3" />
      <rect x="-18" y="-27" width="36" height="54" rx="11" fill="#e4b642" stroke="#fff2cb" strokeWidth="3" />
      <rect x="-12" y="-16" width="24" height="15" rx="5" fill="#b8d1c3" stroke="#286449" strokeWidth="1.5" />
      <rect x="-12" y="6" width="24" height="11" rx="4" fill="#2b684b" />
      <rect x="-20" y="-16" width="4" height="10" rx="2" fill="#35463e" />
      <rect x="16" y="-16" width="4" height="10" rx="2" fill="#35463e" />
      <rect x="-20" y="12" width="4" height="10" rx="2" fill="#35463e" />
      <rect x="16" y="12" width="4" height="10" rx="2" fill="#35463e" />
      <path d="M-7 -22h14" stroke="#fff0bd" strokeWidth="2" strokeLinecap="round" />
      <path d="M-17 2h34" stroke="#fff0bd" strokeWidth="2" opacity=".85" />
      <rect x="-10" y="-6" width="20" height="6" rx="2.5" fill="#f7efd8" stroke="#286449" strokeWidth="1" />
      <text x="0" y="-1.3" textAnchor="middle" fontFamily="Space Mono" fontWeight="700" fontSize="4" fill="#28583f">TAXI</text>
      <g transform="translate(0 21)" aria-label="Nigerian flag taxi livery">
        <rect x="-8" y="-3" width="16" height="6" rx="1" fill="#fff8e6" stroke="#286449" strokeWidth=".8" />
        <rect x="-6.5" y="-1.8" width="4" height="3.6" fill="#087443" />
        <rect x="-2.5" y="-1.8" width="5" height="3.6" fill="#fff8e6" />
        <rect x="2.5" y="-1.8" width="4" height="3.6" fill="#087443" />
      </g>
    </g>
  );
}

function PassengerMarker({ x, y, pickupName }: { x: number; y: number; pickupName: string }) {
  const label = `PICKUP · ${pickupName.toUpperCase()}`;
  const labelWidth = Math.max(106, label.length * 6.3 + 18);
  return (
    <g transform={`translate(${x} ${y})`} data-testid="marker-passenger" aria-label={`Passenger waiting at the ${pickupName} pickup`}>
      <circle r="36" fill="#e7b958" opacity=".28" />
      <circle r="24" fill="#f7f2dc" stroke="#286449" strokeWidth="4" />
      <circle cy="-4" r="6" fill="#dca677" />
      <path d="M-10 12c1-8 4-11 10-11s9 3 10 11" fill="#286449" />
      <rect x="-2" y="-34" width="4" height="10" rx="2" fill="#286449" />
      <circle cy="-38" r="4" fill="#e7b958" />
      <g transform="translate(0 -58)">
        <rect x={-labelWidth / 2} y="-10" width={labelWidth} height="20" rx="10" fill="#28583f" stroke="#f7f2dc" strokeWidth="1.5" />
        <text x="0" y="3.5" textAnchor="middle" fontFamily="Space Mono" fontWeight="700" fontSize="9" letterSpacing=".4" fill="#fff8e7">{label}</text>
      </g>
    </g>
  );
}

function DestinationMarker({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`} data-testid="marker-destination">
      <circle r="34" fill="#e9bd5b" opacity=".2" />
      <circle r="22" fill="#f7f2dc" stroke="#d09d34" strokeWidth="4" />
      <path d="M-9 2 0-8l9 10v9H3V4h-6v7h-6z" fill="#d09d34" />
      <path d="M0-24v-6" stroke="#d09d34" strokeWidth="4" strokeLinecap="round" />
    </g>
  );
}

const RouteOverlay = memo(function RouteOverlay({ origin, destination }: { origin: TaxiStop; destination: TaxiStop }) {
  const start = origin.position;
  const end = destination.position;
  const routePath = start.x === end.x
    ? `M${start.x} ${start.y}V${end.y}`
    : start.y === end.y
      ? `M${start.x} ${start.y}H${end.x}`
      : start.y < end.y
        ? `M${start.x} ${start.y}H${end.x}V${end.y}`
        : `M${start.x} ${start.y}V${end.y}H${end.x}`;
  return (
    <g aria-label={`${origin.name} route to ${destination.name}`}>
      <path d={routePath} fill="none" stroke="#f0c866" strokeWidth="15" strokeDasharray="5 18" strokeLinecap="round" opacity=".42" />
      <path d={routePath} fill="none" stroke="#ffedb3" strokeWidth="4" strokeDasharray="5 18" strokeLinecap="round" opacity=".96" />
    </g>
  );
});

type AbujaCityMapProps = {
  origin: TaxiStop;
  destinationStop: TaxiStop;
  phase: TripPhase;
  taxi: TaxiGameState['taxi'];
  passenger: TaxiGameState['passenger'];
  destination: TaxiGameState['destination'];
};

export function AbujaCityMap({ origin, destinationStop, phase, taxi, passenger, destination }: AbujaCityMapProps) {
  return (
    <svg
      className="city-map"
      viewBox={`0 0 ${GAME_WIDTH} ${GAME_HEIGHT}`}
      role="img"
      aria-label={`Abuja city map showing the ${origin.name} to ${destinationStop.name} taxi trip`}
    >
      <defs>
        <pattern id="city-grain" width="24" height="24" patternUnits="userSpaceOnUse">
          <circle cx="4" cy="5" r="1" fill="#75836a" opacity=".1" />
          <circle cx="18" cy="16" r="1" fill="#75836a" opacity=".08" />
        </pattern>
      </defs>
      <CityBlocks />
      <rect width={GAME_WIDTH} height={GAME_HEIGHT} fill="url(#city-grain)" pointerEvents="none" />
      <RoadNetwork />
      <TrafficLayer />
      <RouteOverlay origin={origin} destination={destinationStop} />
      {phase === 'pickup' && <PassengerMarker x={passenger.x} y={passenger.y} pickupName={origin.name} />}
      {phase !== 'complete' && <DestinationMarker x={destination.x} y={destination.y} />}
      <TaxiMarker x={taxi.x} y={taxi.y} heading={taxi.heading} />
    </svg>
  );
}
