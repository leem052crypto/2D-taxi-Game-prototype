import { useCallback, useEffect, useRef } from 'react';

import type { TripPhase } from './types';

interface Tone {
  frequency: number;
  offset: number;
  duration: number;
}

function playTones(context: AudioContext, tones: readonly Tone[], volume: number) {
  const schedule = () => {
    if (context.state !== 'running') return;
    const start = context.currentTime + 0.02;

    for (const tone of tones) {
      const noteStart = start + tone.offset;
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(tone.frequency, noteStart);
      gain.gain.setValueAtTime(0.0001, noteStart);
      gain.gain.exponentialRampToValueAtTime(volume, noteStart + 0.018);
      gain.gain.exponentialRampToValueAtTime(0.0001, noteStart + tone.duration);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.onended = () => {
        oscillator.disconnect();
        gain.disconnect();
      };
      oscillator.start(noteStart);
      oscillator.stop(noteStart + tone.duration + 0.01);
    }
  };

  if (context.state === 'running') {
    schedule();
  } else {
    void context.resume().then(schedule).catch(() => undefined);
  }
}

export function useTaxiSoundCues(phase: TripPhase, tripsCompleted: number) {
  const audioContextRef = useRef<AudioContext | null>(null);
  const previousStateRef = useRef({ phase, tripsCompleted });

  const unlockAudio = useCallback(() => {
    if (typeof window === 'undefined' || !window.AudioContext) return;

    try {
      audioContextRef.current ??= new window.AudioContext();
      if (audioContextRef.current.state === 'suspended') {
        void audioContextRef.current.resume().catch(() => undefined);
      }
    } catch {
      // Audio is optional; input and gameplay should work if the browser blocks it.
    }
  }, []);

  useEffect(() => {
    const context = audioContextRef.current;
    if (!context) return;

    const previous = previousStateRef.current;
    if (previous.phase === 'pickup' && phase === 'dropoff') {
      playTones(context, [
        { frequency: 587.33, offset: 0, duration: 0.14 },
        { frequency: 783.99, offset: 0.09, duration: 0.18 },
      ], 0.025);
    }
    if (tripsCompleted > previous.tripsCompleted) {
      playTones(context, [
        { frequency: 523.25, offset: 0, duration: 0.16 },
        { frequency: 659.25, offset: 0.1, duration: 0.16 },
        { frequency: 783.99, offset: 0.2, duration: 0.22 },
      ], 0.028);
    }
    previousStateRef.current = { phase, tripsCompleted };
  }, [phase, tripsCompleted]);

  useEffect(() => () => {
    const context = audioContextRef.current;
    if (context && context.state !== 'closed') {
      void context.close().catch(() => undefined);
    }
  }, []);

  return unlockAudio;
}