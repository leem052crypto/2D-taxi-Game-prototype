import {
  GAME_HEIGHT,
  GAME_WIDTH,
  ROAD_X,
  ROAD_Y,
  type Direction,
  type TaxiGameState,
} from './types';
import { FARE_PER_TRIP_NGN, TAXI_STOPS, TAXI_TRIPS } from './routes';

const DRIVE_SPEED = 190;
const TURN_TOLERANCE = 38;
const STOP_MARGIN = 48;
const ARRIVAL_RADIUS = 46;
export function createInitialState(): TaxiGameState {
  const firstTrip = TAXI_TRIPS[0];
  const firstPassenger = TAXI_STOPS[firstTrip.origin].position;
  const firstDestination = TAXI_STOPS[firstTrip.destination].position;

  return {
    taxi: { x: ROAD_X[0], y: ROAD_Y[0], heading: 'right' },
    passenger: { ...firstPassenger },
    destination: { ...firstDestination },
    phase: 'pickup',
    tripIndex: 0,
    boardingRequiresInput: false,
    fare: 0,
    tripsCompleted: 0,
    elapsedSeconds: 0,
  };
}

function nearest(value: number, candidates: readonly number[]) {
  return candidates.reduce((closest, candidate) =>
    Math.abs(candidate - value) < Math.abs(closest - value)
      ? candidate
      : closest,
  );
}

function distance(
  a: { x: number; y: number },
  b: { x: number; y: number },
) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

export function advanceTaxiGame(
  current: TaxiGameState,
  direction: Direction | undefined,
  delta: number,
  timeRemainder: number,
) {
  let next = current;

  if (direction && current.phase !== 'complete') {
    let x = current.taxi.x;
    let y = current.taxi.y;
    let moved = false;

    if (direction === 'left' || direction === 'right') {
      const lane = nearest(y, ROAD_Y);
      if (Math.abs(y - lane) <= TURN_TOLERANCE) {
        y = lane;
        const nextX =
          x + (direction === 'right' ? 1 : -1) * DRIVE_SPEED * delta;
        x = Math.max(STOP_MARGIN, Math.min(GAME_WIDTH - STOP_MARGIN, nextX));
        moved = x !== current.taxi.x;
      }
    } else {
      const lane = nearest(x, ROAD_X);
      if (Math.abs(x - lane) <= TURN_TOLERANCE) {
        x = lane;
        const nextY =
          y + (direction === 'down' ? 1 : -1) * DRIVE_SPEED * delta;
        y = Math.max(STOP_MARGIN, Math.min(GAME_HEIGHT - STOP_MARGIN, nextY));
        moved = y !== current.taxi.y;
      }
    }

    if (moved) {
      timeRemainder += delta;
      const wholeSeconds = Math.floor(timeRemainder);
      timeRemainder -= wholeSeconds;
      next = {
        ...current,
        taxi: { x, y, heading: direction },
        elapsedSeconds: current.elapsedSeconds + wholeSeconds,
      };
    }
  }

  // Check arrivals even while the taxi is stopped, so entering the pickup
  // radius can never depend on another input arriving on a particular frame.
  if (
    next.phase === 'pickup' &&
    distance(next.taxi, next.passenger) <= ARRIVAL_RADIUS &&
    (!next.boardingRequiresInput || direction !== undefined)
  ) {
    next = {
      ...next,
      taxi: { ...next.taxi, x: next.passenger.x, y: next.passenger.y },
      phase: 'dropoff',
      boardingRequiresInput: false,
    };
  } else if (
    next.phase === 'dropoff' &&
    distance(next.taxi, next.destination) <= ARRIVAL_RADIUS
  ) {
    const tripsCompleted = next.tripsCompleted + 1;
    const fare = next.fare + FARE_PER_TRIP_NGN;
    const taxi = { ...next.taxi, x: next.destination.x, y: next.destination.y };
    const nextTripIndex = next.tripIndex + 1;

    if (nextTripIndex === TAXI_TRIPS.length) {
      next = {
        ...next,
        taxi,
        phase: 'complete',
        boardingRequiresInput: false,
        fare,
        tripsCompleted,
      };
    } else {
      const nextTrip = TAXI_TRIPS[nextTripIndex];
      const passenger = TAXI_STOPS[nextTrip.origin].position;
      const destination = TAXI_STOPS[nextTrip.destination].position;

      next = {
        ...next,
        taxi,
        passenger: { ...passenger },
        destination: { ...destination },
        phase: 'pickup',
        tripIndex: nextTripIndex,
        boardingRequiresInput: distance(taxi, passenger) <= ARRIVAL_RADIUS,
        fare,
        tripsCompleted,
      };
    }
  }

  return {
    state: next,
    timeRemainder,
    tripCompleted: next.tripsCompleted > current.tripsCompleted,
  };
}