export type Direction = 'up' | 'down' | 'left' | 'right';

export type TripPhase = 'pickup' | 'dropoff' | 'complete';

export interface TaxiGameState {
  taxi: {
    x: number;
    y: number;
    heading: Direction;
  };
  passenger: {
    x: number;
    y: number;
  };
  destination: {
    x: number;
    y: number;
  };
  phase: TripPhase;
  tripIndex: number;
  boardingRequiresInput: boolean;
  fare: number;
  tripsCompleted: number;
  elapsedSeconds: number;
}

export interface TaxiGameControls {
  state: TaxiGameState;
  press: (direction: Direction) => void;
  release: (direction: Direction) => void;
  reset: () => void;
}

export const GAME_WIDTH = 1280;
export const GAME_HEIGHT = 960;
export const ROAD_X = [128, 384, 640, 896, 1152] as const;
export const ROAD_Y = [120, 300, 480, 660, 840] as const;