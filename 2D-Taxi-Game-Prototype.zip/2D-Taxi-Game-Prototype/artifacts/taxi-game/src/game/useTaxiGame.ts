import { useCallback, useEffect, useRef, useState } from 'react';

import {
  type Direction,
  type TaxiGameState,
} from './types';
import { advanceTaxiGame, createInitialState } from './logic';

export function useTaxiGame() {
  const [state, setState] = useState<TaxiGameState>(createInitialState);
  const stateRef = useRef(state);
  const pressedDirections = useRef<Direction[]>([]);

  const update = useCallback((next: TaxiGameState) => {
    stateRef.current = next;
    setState(next);
  }, []);

  const press = useCallback((direction: Direction) => {
    pressedDirections.current = pressedDirections.current.filter(
      (pressed) => pressed !== direction,
    );
    pressedDirections.current.push(direction);
  }, []);

  const release = useCallback((direction: Direction) => {
    pressedDirections.current = pressedDirections.current.filter(
      (pressed) => pressed !== direction,
    );
  }, []);

  const reset = useCallback(() => {
    pressedDirections.current = [];
    update(createInitialState());
  }, [update]);

  useEffect(() => {
    let frame = 0;
    let previousTime = 0;
    let timeRemainder = 0;

    const tick = (now: number) => {
      if (!previousTime) previousTime = now;
      const delta = Math.min((now - previousTime) / 1000, 0.05);
      previousTime = now;

      const current = stateRef.current;
      const { state: next, timeRemainder: nextTimeRemainder, tripCompleted } =
        advanceTaxiGame(
          current,
          pressedDirections.current.at(-1),
          delta,
          timeRemainder,
        );
      timeRemainder = nextTimeRemainder;
      if (tripCompleted) pressedDirections.current = [];
      if (next !== current) update(next);

      frame = window.requestAnimationFrame(tick);
    };

    frame = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(frame);
  }, [update]);

  return { state, press, release, reset };
}