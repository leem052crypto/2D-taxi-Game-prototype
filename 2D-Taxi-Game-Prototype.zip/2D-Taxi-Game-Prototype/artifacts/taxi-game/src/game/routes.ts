import { ROAD_X, ROAD_Y } from './types';

export type TaxiStopId = 'wuse' | 'garki' | 'centralArea' | 'wuse2';

export interface TaxiStop {
  name: string;
  shortLabel: string;
  routeCode: string;
  position: { x: number; y: number };
}

export const TAXI_STOPS = {
  wuse: {
    name: 'Wuse',
    shortLabel: 'WUSE',
    routeCode: 'W',
    position: { x: ROAD_X[3], y: ROAD_Y[1] },
  },
  garki: {
    name: 'Garki',
    shortLabel: 'GARKI',
    routeCode: 'G',
    position: { x: ROAD_X[2], y: ROAD_Y[4] },
  },
  centralArea: {
    name: 'Central Area',
    shortLabel: 'CENTRAL',
    routeCode: 'CA',
    position: { x: ROAD_X[2], y: ROAD_Y[2] },
  },
  wuse2: {
    name: 'Wuse 2',
    shortLabel: 'WUSE 2',
    routeCode: 'W2',
    position: { x: ROAD_X[0], y: ROAD_Y[1] },
  },
} as const satisfies Record<TaxiStopId, TaxiStop>;

export interface TaxiTrip {
  origin: TaxiStopId;
  destination: TaxiStopId;
}

export const TAXI_TRIPS = [
  { origin: 'wuse', destination: 'garki' },
  { origin: 'garki', destination: 'wuse' },
  { origin: 'wuse', destination: 'centralArea' },
  { origin: 'centralArea', destination: 'garki' },
  { origin: 'garki', destination: 'wuse2' },
] as const satisfies readonly TaxiTrip[];

export const TOTAL_TRIPS = TAXI_TRIPS.length;
export const FARE_PER_TRIP_NGN = 24_000;