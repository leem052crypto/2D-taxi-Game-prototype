import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Car, Clock3, MapPinned, RotateCcw, Wallet } from 'lucide-react';
import { AbujaCityMap } from '@/components/AbujaCityMap';
import { useTaxiGame } from '@/game/useTaxiGame';
import { useTaxiSoundCues } from '@/game/useTaxiSoundCues';
import { FARE_PER_TRIP_NGN, TAXI_STOPS, TAXI_TRIPS, TOTAL_TRIPS } from '@/game/routes';
import type { Direction } from '@/game/types';

const directions: { direction: Direction; Icon: typeof ArrowUp; label: string }[] = [
  { direction: 'up', Icon: ArrowUp, label: 'Up' },
  { direction: 'left', Icon: ArrowLeft, label: 'Left' },
  { direction: 'down', Icon: ArrowDown, label: 'Down' },
  { direction: 'right', Icon: ArrowRight, label: 'Right' },
];

const keyToDirection: Record<string, Direction> = {
  ArrowUp: 'up', KeyW: 'up',
  ArrowDown: 'down', KeyS: 'down',
  ArrowLeft: 'left', KeyA: 'left',
  ArrowRight: 'right', KeyD: 'right',
};

function NigeriaFlag() {
  return (
    <svg className="nigeria-flag" viewBox="0 0 18 12" role="img" aria-label="Nigerian flag">
      <rect width="18" height="12" rx="1" fill="#f9f5e8" />
      <path d="M0 1a1 1 0 0 1 1-1h5v12H1a1 1 0 0 1-1-1zM12 0h5a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-5z" fill="#087443" />
      <rect x=".5" y=".5" width="17" height="11" rx=".7" fill="none" stroke="#d9cfb6" />
    </svg>
  );
}

function formatTime(seconds: number) {
  const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
  const secs = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
}

function formatNgn(amount: number) {
  return `₦${amount.toLocaleString('en-NG')}`;
}

function App() {
  const { state, press, release, reset } = useTaxiGame();
  const unlockAudio = useTaxiSoundCues(state.phase, state.tripsCompleted);
  const heldKeys = useRef(new Set<string>());
  const [pressedDirections, setPressedDirections] = useState<Direction[]>([]);

  const releaseAll = useCallback(() => {
    for (const key of heldKeys.current) {
      const direction = keyToDirection[key];
      if (direction) release(direction);
    }
    heldKeys.current.clear();
    setPressedDirections([]);
  }, [release]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const direction = keyToDirection[event.code];
      if (!direction) return;
      event.preventDefault();
      if (heldKeys.current.has(event.code)) return;
      unlockAudio();
      heldKeys.current.add(event.code);
      press(direction);
      setPressedDirections((current) => current.includes(direction) ? current : [...current, direction]);
    };
    const onKeyUp = (event: KeyboardEvent) => {
      const direction = keyToDirection[event.code];
      if (!direction || !heldKeys.current.has(event.code)) return;
      event.preventDefault();
      heldKeys.current.delete(event.code);
      release(direction);
      setPressedDirections((current) => current.filter((item) => item !== direction));
    };
    const onBlur = () => releaseAll();
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
      releaseAll();
    };
  }, [press, release, releaseAll, unlockAudio]);

  const pointerPress = (direction: Direction) => {
    unlockAudio();
    press(direction);
    setPressedDirections((current) => current.includes(direction) ? current : [...current, direction]);
  };
  const pointerRelease = (direction: Direction) => {
    release(direction);
    setPressedDirections((current) => current.filter((item) => item !== direction));
  };

  const { taxi, passenger, destination, phase, fare, tripsCompleted, elapsedSeconds } = state;
  const trip = TAXI_TRIPS[Math.min(state.tripIndex, TOTAL_TRIPS - 1)]!;
  const originStop = TAXI_STOPS[trip.origin];
  const destinationStop = TAXI_STOPS[trip.destination];
  const isComplete = phase === 'complete';
  const target = phase === 'pickup' ? passenger : destination;
  const distance = Math.hypot(target.x - taxi.x, target.y - taxi.y);
  const progress = isComplete ? 100 : Math.max(5, Math.min(95, 100 - distance / 7.8));
  const objective = isComplete
    ? 'All five trips complete.'
    : phase === 'pickup'
      ? `Pick up in ${originStop.name}.`
      : `Drop off in ${destinationStop.name}.`;
  const objectiveSub = isComplete
    ? `You collected ${formatNgn(fare)} across ${TOTAL_TRIPS} paid trips.`
    : phase === 'pickup'
      ? `Passenger waiting in ${originStop.name}. Earn ${formatNgn(FARE_PER_TRIP_NGN)} at drop-off.`
      : `Take this passenger to ${destinationStop.name}. Fare: ${formatNgn(FARE_PER_TRIP_NGN)}.`;

  return (
    <main className="game-shell">
      <div className="game-wrap">
        <header className="topbar">
          <div className="brand">
            <div className="brand-mark" aria-hidden="true"><Car size={22} strokeWidth={2.2} /></div>
            <div><div className="brand-name">Abuja City Taxi</div><div className="brand-kicker">Wuse 2 · Central Area · Garki</div></div>
          </div>
          <div className="top-status"><span className="live-dot" /> ON THE ROAD <span aria-hidden="true">·</span> ABUJA CITY SERVICE</div>
        </header>

        <section className="hero-line" aria-label="Game introduction">
          <div>
            <div className="eyebrow">Abuja · Federal Capital Territory</div>
            <h1>{isComplete ? <>All five trips <span>complete.</span></> : <>{originStop.name} to <span>{destinationStop.name}.</span></>}</h1>
            <p className="hero-copy">{isComplete ? 'All five fares collected. Start a fresh shift to run them again.' : `Trip ${state.tripIndex + 1} of ${TOTAL_TRIPS} · Earn ${formatNgn(FARE_PER_TRIP_NGN)} at each drop-off.`}</p>
          </div>
          <button className="reset-button" onClick={() => { releaseAll(); reset(); }} data-testid="button-reset">
            <RotateCcw size={15} /> Start a fresh shift
          </button>
        </section>

        <div className="game-layout">
          <section className="map-card" aria-label="Playable city map">
            <div className="map-topline">
              <div className="map-label"><NigeriaFlag /><MapPinned size={14} /> ABUJA · FCT</div>
              <div className="map-coordinate"><span className="route-sign-shield">FCT</span><span>{originStop.shortLabel}</span><ArrowRight size={12} /><span>{destinationStop.shortLabel}</span></div>
            </div>
            <div className="map-viewport">
              <AbujaCityMap
                origin={originStop}
                destinationStop={destinationStop}
                phase={phase}
                taxi={taxi}
                passenger={passenger}
                destination={destination}
              />
            </div>
            <div className="map-footer">
              <div className="map-legend">
                <span className="legend-item"><i className="legend-swatch" /> Your Abuja taxi</span>
                {phase === 'pickup' && <span className="legend-item"><i className="legend-swatch passenger" /> Passenger</span>}
                {!isComplete && <span className="legend-item"><i className="legend-swatch destination" /> Drop-off</span>}
              </div>
              <span className="map-note">ABUJA, NIGERIA · FCT</span>
            </div>
          </section>

          <section className="below-map" aria-label="Shift details and driving controls">
            <div className="below-map-main">
              <section className="mission-card primary" data-testid="status-objective">
                <div className="mission-head">
                  <span className="mission-title">{isComplete ? 'Shift complete' : `Trip ${state.tripIndex + 1} of ${TOTAL_TRIPS}`}</span>
                  <span className="phase-tag">{isComplete ? 'Finished' : phase === 'pickup' ? 'Pickup' : 'En route'}</span>
                </div>
                <h2 className="mission-text">{objective}</h2>
                <p className="mission-sub">{objectiveSub}</p>
                <div className="trip-route" aria-label={`${originStop.name} to ${destinationStop.name}; trip progress ${Math.round(progress)} percent`}>
                  <span className="route-pin">{originStop.routeCode}</span><span className="route-line" /><span className="route-pin">{destinationStop.routeCode}</span>
                </div>
                <div className="trip-progress" aria-hidden="true">
                  {[0, 1, 2, 3, 4, 5, 6].map((step) => <i key={step} className={step / 7 < progress / 100 ? 'active' : ''} />)}
                </div>
                {isComplete && <div className="complete-banner">Five fares paid: {formatNgn(fare)} total.</div>}
              </section>

              <section className="controls-card">
                <div className="drive-copy">
                  <div className="controls-title"><Car size={15} /> Drive the cab</div>
                  <p className="controls-caption">Hold a direction to cruise through town.</p>
                  <div className="key-hints" aria-label="Keyboard controls">
                    <span className="keycap">W</span><span className="keycap">A</span><span className="keycap">S</span><span className="keycap">D</span>
                    <span className="keycap">or</span>
                    <span className="keycap">← ↑ ↓ →</span>
                  </div>
                  <p className="controls-footnote">Keyboard or tap the arrows</p>
                </div>
                <div className="control-layout" aria-label="On-screen directional controls">
                  {directions.map(({ direction, Icon, label }) => (
                    <button
                      key={direction}
                      className={`direction-key ${direction} ${pressedDirections.includes(direction) ? 'is-pressed' : ''}`}
                      aria-label={`Drive ${label.toLowerCase()}`}
                      aria-keyshortcuts={direction === 'up' ? 'ArrowUp W' : direction === 'down' ? 'ArrowDown S' : direction === 'left' ? 'ArrowLeft A' : 'ArrowRight D'}
                      data-testid={`button-drive-${direction}`}
                      onPointerDown={(event) => { event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); pointerPress(direction); }}
                      onPointerUp={() => pointerRelease(direction)}
                      onPointerCancel={() => pointerRelease(direction)}
                      onLostPointerCapture={() => pointerRelease(direction)}
                    >
                      <Icon size={17} strokeWidth={2.5} />
                    </button>
                  ))}
                </div>
              </section>
            </div>

            <section className="shift-panel" aria-label="Five-trip shift ledger">
              <div className="shift-panel-heading">
                <div>
                  <h2>Shift ledger</h2>
                  <p>Five fares · {formatNgn(FARE_PER_TRIP_NGN)} each</p>
                </div>
                <span className="ledger-total">{formatNgn(FARE_PER_TRIP_NGN * TOTAL_TRIPS)} total</span>
              </div>
              <div className="shift-summary">
                <section className="summary-stat" data-testid="text-fare">
                  <span className="summary-label"><Wallet size={11} /> Total earned</span>
                  <strong className="summary-value">{formatNgn(fare)}</strong>
                </section>
                <section className="summary-stat" data-testid="text-trip-time">
                  <span className="summary-label"><Clock3 size={11} /> Shift duration</span>
                  <strong className="summary-value">{formatTime(elapsedSeconds)}</strong>
                </section>
                <section className="summary-stat" data-testid="text-trips">
                  <span className="summary-label">Trips completed</span>
                  <strong className="summary-value">{tripsCompleted}<small> / {TOTAL_TRIPS}</small></strong>
                </section>
              </div>
              <div className="trip-ledger">
                {TAXI_TRIPS.map((leg, index) => {
                  const completed = index < tripsCompleted;
                  const current = !isComplete && index === state.tripIndex;
                  const from = TAXI_STOPS[leg.origin].shortLabel;
                  const to = TAXI_STOPS[leg.destination].shortLabel;
                  const status = completed ? 'PAID' : current ? (phase === 'pickup' ? 'PICKUP' : 'EN ROUTE') : 'NEXT UP';
                  return (
                    <div key={`${leg.origin}-${leg.destination}-${index}`} className={`ledger-row${current ? ' current' : ''}${completed ? ' completed' : ''}`} aria-current={current ? 'step' : undefined}>
                      <span className="ledger-number">0{index + 1}</span>
                      <span className="ledger-route"><span>{from}</span><ArrowRight size={12} /><span>{to}</span></span>
                      <span className="ledger-status">{status}</span>
                      <strong className="ledger-fare">{formatNgn(FARE_PER_TRIP_NGN)}</strong>
                    </div>
                  );
                })}
              </div>
              <p className="ledger-note">Earn each fare at its drop-off. Complete all five rides to finish the shift.</p>
            </section>
          </section>
        </div>
      </div>
    </main>
  );
}

export default App;