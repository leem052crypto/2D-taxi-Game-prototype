import { useState, type CSSProperties } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, CarFront, Clock3, MapPinned, WalletCards } from 'lucide-react';
import './expanded.css';

const WIDTH = 1280;
const HEIGHT = 960;
const ROAD_X = [128, 384, 640, 896, 1152];
const ROAD_Y = [120, 300, 480, 660, 840];

type Direction = 'up' | 'down' | 'left' | 'right';

const directions: { direction: Direction; Icon: typeof ArrowUp; label: string }[] = [
  { direction: 'up', Icon: ArrowUp, label: 'Up' },
  { direction: 'left', Icon: ArrowLeft, label: 'Left' },
  { direction: 'down', Icon: ArrowDown, label: 'Down' },
  { direction: 'right', Icon: ArrowRight, label: 'Right' },
];

const trips = [
  { from: 'Wuse', to: 'Garki' },
  { from: 'Garki', to: 'Wuse' },
  { from: 'Wuse', to: 'Central Area' },
  { from: 'Central Area', to: 'Garki' },
  { from: 'Garki', to: 'Wuse 2' },
];

function NigeriaFlag() {
  return (
    <svg className="nigeria-flag" viewBox="0 0 18 12" role="img" aria-label="Nigerian flag">
      <rect width="18" height="12" rx="1" fill="#fffaf0" />
      <path d="M0 1a1 1 0 0 1 1-1h5v12H1a1 1 0 0 1-1-1zM12 0h5a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-5z" fill="#087443" />
      <rect x=".5" y=".5" width="17" height="11" rx=".7" fill="none" stroke="#d7c9aa" />
    </svg>
  );
}

function Tree({ x, y, scale = 1 }: { x: number; y: number; scale?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`}>
      <ellipse cx="0" cy="8" rx="13" ry="4" fill="#637b4d" opacity=".2" />
      <path d="M-2 8h4V-6h-4z" fill="#8a7148" />
      <circle cx="0" cy="-12" r="10" fill="#658454" />
      <circle cx="-7" cy="-8" r="6" fill="#77925f" />
      <circle cx="7" cy="-8" r="6" fill="#57784f" />
      <circle cx="1" cy="-18" r="5" fill="#879b67" />
    </g>
  );
}

function Taxi({ x, y, heading = 'right' }: { x: number; y: number; heading?: Direction }) {
  const rotation = { up: -90, right: 0, down: 90, left: 180 }[heading];
  return (
    <g transform={`translate(${x} ${y}) rotate(${rotation})`} data-testid="marker-taxi">
      <ellipse cx="1" cy="13" rx="28" ry="17" fill="#27352e" opacity=".26" />
      <rect x="-27" y="-15" width="54" height="30" rx="10" fill="#e7b74d" stroke="#fff0c8" strokeWidth="3" />
      <path d="M-13-11h22a7 7 0 0 1 7 6v8h-36v-8a7 7 0 0 1 7-6z" fill="#9ebdaa" stroke="#315f48" strokeWidth="2" />
      <path d="M-11-8h9v9h-14v-3a6 6 0 0 1 5-6zm13 0h7a4 4 0 0 1 4 4v5H2z" fill="#d9e3cf" opacity=".9" />
      <rect x="-28" y="-10" width="5" height="9" rx="2" fill="#3c4940" />
      <rect x="23" y="-10" width="5" height="9" rx="2" fill="#3c4940" />
      <rect x="-28" y="3" width="5" height="9" rx="2" fill="#3c4940" />
      <rect x="23" y="3" width="5" height="9" rx="2" fill="#3c4940" />
      <path d="M-25-12h8m34 0h8" stroke="#fff6dc" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M-26 1h52" stroke="#fff3cf" strokeWidth="2" opacity=".9" />
      <rect x="-9" y="-17" width="18" height="6" rx="2" fill="#fff7e4" stroke="#386249" strokeWidth="1" />
      <text x="0" y="-12.5" textAnchor="middle" fill="#2f6044" fontSize="4.5" fontWeight="700" fontFamily="Space Mono">TAXI</text>
      <g transform="translate(0 12)">
        <rect x="-7" y="-2.5" width="14" height="5" rx="1" fill="#fff8e7" />
        <path d="M-6-2h4v4h-4zm8 0h4v4H2z" fill="#087443" />
      </g>
    </g>
  );
}

function Passenger({ x, y, label }: { x: number; y: number; label: string }) {
  return (
    <g transform={`translate(${x} ${y})`} data-testid="marker-passenger" aria-label={`Passenger pickup in ${label}`}>
      <circle r="35" fill="#f3ce6a" opacity=".32" />
      <circle r="23" fill="#fff8e7" stroke="#276b4b" strokeWidth="4" />
      <circle cy="-5" r="5.5" fill="#c88965" />
      <path d="M-10 12c.7-8 4-11 10-11s9.3 3 10 11" fill="#276b4b" />
      <path d="M0-27v-8" stroke="#276b4b" strokeWidth="4" strokeLinecap="round" />
      <circle cy="-39" r="5" fill="#e4b647" stroke="#fff8e7" strokeWidth="1.5" />
      <g transform="translate(0 -61)">
        <rect x="-52" y="-10" width="104" height="20" rx="7" fill="#236448" stroke="#fff5d9" strokeWidth="2" />
        <text className="pickup-tag" textAnchor="middle" y="3">PICK UP · {label.toUpperCase()}</text>
      </g>
    </g>
  );
}

function Destination({ x, y, label }: { x: number; y: number; label: string }) {
  return (
    <g transform={`translate(${x} ${y})`} data-testid="marker-destination" aria-label={`Drop-off destination ${label}`}>
      <circle r="32" fill="#cf7752" opacity=".21" />
      <circle r="22" fill="#fff7e5" stroke="#c56743" strokeWidth="3.5" />
      <path d="M-10 0 0-9 10 0v10H3V3h-6v7h-7z" fill="#bb6342" />
      <path d="M0-23v-7" stroke="#bc6542" strokeWidth="3" strokeLinecap="round" />
      <g transform="translate(0 43)">
        <rect x="-39" y="-9" width="78" height="18" rx="6" fill="#a95437" stroke="#fff5dd" strokeWidth="1.5" />
        <text className="drop-tag" textAnchor="middle" y="3">{label.toUpperCase()} · DROP</text>
      </g>
    </g>
  );
}

function StopWaypoint({ x, y, code, name, align = 'left' }: { x: number; y: number; code: string; name: string; align?: 'left' | 'right' }) {
  const left = align === 'left';
  const labelX = left ? -68 : 68;
  return (
    <g transform={`translate(${x} ${y})`} aria-label={`${name} route stop`}>
      <circle r="13" fill="#fff4d6" stroke="#47704f" strokeWidth="3" />
      <circle r="4" fill="#47704f" />
      <g transform={`translate(${labelX} -27)`}>
        <rect x={left ? -57 : -4} y="-10" width="61" height="19" rx="6" fill="#315f47" stroke="#fff3d8" strokeWidth="1.3" />
        <text x={left ? -27 : 26} y="2.8" textAnchor="middle" className="waypoint-tag">{code} · {name.toUpperCase()}</text>
      </g>
    </g>
  );
}

function MiniCar({ x, y, color, movement, delay = '' }: { x: number; y: number; color: string; movement: 'east' | 'west' | 'south'; delay?: string }) {
  const style = { '--travel-time': movement === 'south' ? '19s' : '16s' } as CSSProperties;
  return (
    <g transform={`translate(${x} ${y})`} aria-hidden="true">
      <g className={`traffic-car traffic-${movement}${delay ? ` ${delay}` : ''}`} style={style}>
        <g transform={movement === 'south' ? 'rotate(90 13 6.5)' : undefined}>
          <rect width="26" height="14" rx="5" fill="#27342d" opacity=".23" transform="translate(1 2)" />
          <rect width="26" height="13" rx="4.5" fill={color} stroke="#f7ebcc" strokeWidth="1.5" />
          <path d="M6 2h12a3 3 0 0 1 3 3v3H4V5a3 3 0 0 1 2-3z" fill="#b8cbb6" stroke="#526e59" strokeWidth=".8" />
          <rect x="2" y="2" width="2" height="3" rx="1" fill="#34423b" />
          <rect x="22" y="2" width="2" height="3" rx="1" fill="#34423b" />
          <rect x="2" y="9" width="2" height="3" rx="1" fill="#34423b" />
          <rect x="22" y="9" width="2" height="3" rx="1" fill="#34423b" />
        </g>
      </g>
    </g>
  );
}

function Market({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <rect x="-67" y="-25" width="134" height="52" rx="5" fill="#d8c393" stroke="#9d8760" strokeWidth="2" />
      <rect x="-63" y="-20" width="126" height="14" rx="3" fill="#176646" />
      <path d="M-55-20h16v14h-16zm32 0h16v14h-16zm32 0h16v14H9zm32 0h16v14H41z" fill="#e8b74d" />
      <rect x="-51" y="-3" width="28" height="24" rx="2" fill="#91ad9a" stroke="#f5e9cb" />
      <rect x="-12" y="-3" width="24" height="24" rx="2" fill="#a8bca5" stroke="#f5e9cb" />
      <rect x="25" y="-3" width="27" height="24" rx="2" fill="#8aa891" stroke="#f5e9cb" />
      <path d="M-63-4h126" stroke="#bd6947" strokeWidth="3" />
      <text x="0" y="39" textAnchor="middle" className="place-label">WUSE MARKET</text>
      <g fill="#d87f43">
        <circle cx="-78" cy="-13" r="4" /><circle cx="78" cy="-10" r="4" /><circle cx="-78" cy="5" r="4" /><circle cx="78" cy="8" r="4" />
      </g>
    </g>
  );
}

function Mosque({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <ellipse cx="0" cy="43" rx="72" ry="10" fill="#60744c" opacity=".2" />
      <rect x="-49" y="-8" width="98" height="49" rx="5" fill="#e7dfc2" stroke="#a79467" strokeWidth="2" />
      <path d="M-37-8c2-51 72-51 74 0" fill="#65886c" stroke="#3b694d" strokeWidth="2" />
      <path d="M-36-8h72M-49 1h98" stroke="#c9b678" strokeWidth="3" />
      <path d="M0-52v-15m-5 1 5-8 5 8" fill="none" stroke="#b68b3c" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M-58-4v-45q0-6 6-6t6 6v50M46 1v-50q0-6 6-6t6 6v50" fill="#e5d6aa" stroke="#ae9866" strokeWidth="2" />
      <path d="M-53-57v-9m-4 1 4-6 4 6m51 14v-10m-4 1 4-6 4 6m53 9v-9m-4 1 4-6 4 6" fill="none" stroke="#ad843d" strokeWidth="2" />
      <path d="M-11 41V21a11 11 0 0 1 22 0v20" fill="#789473" />
      <rect x="-38" y="4" width="11" height="16" rx="5" fill="#a9b99f" />
      <rect x="27" y="4" width="11" height="16" rx="5" fill="#a9b99f" />
      <text x="0" y="62" textAnchor="middle" className="place-label">NATIONAL MOSQUE</text>
    </g>
  );
}

function NationalAssembly({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <ellipse cx="0" cy="43" rx="65" ry="9" fill="#65744c" opacity=".2" />
      <path d="M-62-12 0-40 62-12z" fill="#e6d5a9" stroke="#a38d5d" strokeWidth="2" />
      <rect x="-57" y="-12" width="114" height="47" rx="3" fill="#d6c391" stroke="#a38d5d" strokeWidth="2" />
      <rect x="-50" y="-6" width="100" height="6" fill="#bda46e" />
      {[-39,-20,0,20,39].map((cx) => <g key={cx}>
        <rect x={cx-4} y="0" width="8" height="31" rx="2" fill="#f0e3bd" stroke="#b59b63" />
        <path d={`M${cx-6} 1h12`} stroke="#8e7950" strokeWidth="2" />
      </g>)}
      <rect x="-11" y="-24" width="22" height="11" rx="3" fill="#ddcda1" stroke="#ac9565" />
      <path d="M-14 35h28" stroke="#ad965f" strokeWidth="3" />
      <text x="0" y="53" textAnchor="middle" className="place-label">NATIONAL ASSEMBLY</text>
    </g>
  );
}

function AsoRock({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <path d="M-115 75  -96 32 -78 42 -59 3 -44 24 -22-45 0-10 19-32 37-6 54-29 74 12 91 5 115 75Z" fill="#ad8755" stroke="#927046" strokeWidth="2" />
      <path d="m-78 42 19-39 15 21L-22-45 0-10l19-22 18 26 17-23 20 41" fill="none" stroke="#d6b982" strokeWidth="3" opacity=".8" />
      <path d="M-110 76q110-15 220 0" stroke="#738a5e" strokeWidth="11" />
      <text x="0" y="99" textAnchor="middle" className="place-label">ASO ROCK · ABUJA'S BACKDROP</text>
    </g>
  );
}

function Lake() {
  return (
    <g>
      <path d="M418 21q36-9 65 2 35 13 65 3 28-9 50 1v67q-29 8-57 1-36-9-65 1-31 12-58 0z" fill="#8bb6ae" stroke="#f1e9c9" strokeWidth="5" />
      <path d="M425 43q28-10 53-2m-41 19q32-8 57 1m20-19q25 11 49 1m-31 25q29-8 54 0" fill="none" stroke="#c8ded0" strokeWidth="3" strokeLinecap="round" />
      <path d="M423 83q42 9 76 0 30-8 54 1 22 7 44 1" fill="none" stroke="#5d987f" strokeWidth="2" />
      <rect x="460" y="27" width="79" height="20" rx="7" fill="#315f4d" stroke="#f8f1d9" strokeWidth="1.5" />
      <text x="499.5" y="40.3" textAnchor="middle" className="landmark-label">JABI LAKE</text>
      <Tree x={436} y={89} scale={.74} /><Tree x={573} y={92} scale={.7} />
    </g>
  );
}

function MapArt() {
  const blocks = [
    { x: 17, y: 19, w: 96, h: 82, fill: '#d4dcb5' },
    { x: 151, y: 18, w: 212, h: 82, fill: '#e4d8b8' },
    { x: 402, y: 18, w: 222, h: 82, fill: '#c9d7b2' },
    { x: 662, y: 18, w: 213, h: 82, fill: '#e4d5ae' },
    { x: 918, y: 18, w: 214, h: 82, fill: '#d5dfbb' },
    { x: 1170, y: 18, w: 93, h: 82, fill: '#e0d7b8' },
    { x: 18, y: 142, w: 96, h: 139, fill: '#dbd5b3' },
    { x: 151, y: 142, w: 212, h: 139, fill: '#d4dfbe' },
    { x: 402, y: 142, w: 222, h: 139, fill: '#eadbb8' },
    { x: 662, y: 142, w: 213, h: 139, fill: '#d5deb9' },
    { x: 918, y: 142, w: 214, h: 139, fill: '#e7d6ae' },
    { x: 1170, y: 142, w: 93, h: 139, fill: '#d9ddb9' },
    { x: 18, y: 322, w: 96, h: 139, fill: '#e2d9b8' },
    { x: 151, y: 322, w: 212, h: 139, fill: '#d5ddba' },
    { x: 402, y: 322, w: 222, h: 139, fill: '#e7d9b7' },
    { x: 662, y: 322, w: 213, h: 139, fill: '#cbd9b4' },
    { x: 918, y: 322, w: 214, h: 139, fill: '#ded4b0' },
    { x: 1170, y: 322, w: 93, h: 139, fill: '#d3ddb9' },
    { x: 18, y: 502, w: 96, h: 139, fill: '#d1dcb6' },
    { x: 151, y: 502, w: 212, h: 139, fill: '#e8d9b7' },
    { x: 402, y: 502, w: 222, h: 139, fill: '#d4dfbb' },
    { x: 662, y: 502, w: 213, h: 139, fill: '#e3d8b6' },
    { x: 918, y: 502, w: 214, h: 139, fill: '#d0dbb5' },
    { x: 1170, y: 502, w: 93, h: 139, fill: '#e6d7b1' },
    { x: 18, y: 682, w: 96, h: 139, fill: '#e3d9b8' },
    { x: 151, y: 682, w: 212, h: 139, fill: '#d3dcb7' },
    { x: 402, y: 682, w: 222, h: 139, fill: '#e2d5b0' },
    { x: 662, y: 682, w: 213, h: 139, fill: '#d1dcb8' },
    { x: 918, y: 682, w: 214, h: 139, fill: '#e5d7b5' },
    { x: 1170, y: 682, w: 93, h: 139, fill: '#d7ddb9' },
    { x: 18, y: 862, w: 96, h: 80, fill: '#d1dcb7' },
    { x: 151, y: 862, w: 212, h: 80, fill: '#e8d9b9' },
    { x: 402, y: 862, w: 222, h: 80, fill: '#d3dcb8' },
    { x: 662, y: 862, w: 213, h: 80, fill: '#e2d7b8' },
    { x: 918, y: 862, w: 214, h: 80, fill: '#d3ddb8' },
    { x: 1170, y: 862, w: 93, h: 80, fill: '#e3d8b6' },
  ];
  const parcelRows = [170, 350, 530, 710, 890];

  return (
    <>
      <rect width={WIDTH} height={HEIGHT} fill="#c5d3ad" />
      <path d="M0 0h1280v960H0z" fill="#d8dfbb" />
      {blocks.map((block, i) => (
        <g key={`block-${i}`}>
          <rect x={block.x} y={block.y} width={block.w} height={block.h} rx="13" fill={block.fill} stroke="#b8bd98" strokeWidth="1.2" />
          {i % 5 !== 0 && i % 5 !== 2 && (
            <g fill={i % 2 ? '#e8ddbf' : '#c9d4b1'} opacity=".88">
              <rect x={block.x + 11} y={block.y + 15} width={Math.max(28, block.w * .37)} height="22" rx="5" />
              <rect x={block.x + block.w * .54} y={block.y + 16} width={Math.max(25, block.w * .34)} height="18" rx="5" />
              {block.h > 100 && <rect x={block.x + 15} y={block.y + 53} width={Math.max(31, block.w * .65)} height="22" rx="6" />}
            </g>
          )}
          {block.h > 100 && (
            <g>
              <Tree x={block.x + 17} y={block.y + block.h - 18} scale={.58} />
              <Tree x={block.x + block.w - 16} y={block.y + block.h - 18} scale={.53} />
              {block.w > 150 && <Tree x={block.x + block.w * .51} y={block.y + block.h - 18} scale={.48} />}
            </g>
          )}
        </g>
      ))}

      {/* District character: landscaped estates, crescents and a lakefront. */}
      <g opacity=".78">
        <path d="M167 180h179m-179 17h179m-179 17h179m-179 17h179" stroke="#b9c59e" strokeWidth="1" strokeDasharray="5 5" />
        <path d="M945 178h157m-157 18h157m-157 18h157m-157 18h157" stroke="#b9c59e" strokeWidth="1" strokeDasharray="5 5" />
        <path d="M170 744q75-37 166 0m-164 20q76-35 164 2" stroke="#bdcaa0" strokeWidth="3" fill="none" />
        <path d="M950 740q75-35 157 3m-155 17q74-34 155 2" stroke="#bdcaa0" strokeWidth="3" fill="none" />
      </g>

      {/* Roads are centered on the integration grid. */}
      {ROAD_X.map((x) => (
        <g key={`vertical-road-${x}`}>
          <rect x={x - 42} y="0" width="84" height={HEIGHT} fill="#b9ae8a" opacity=".46" />
          <rect x={x - 36} y="0" width="72" height={HEIGHT} fill="#58645a" />
          <path d={`M${x - 30} 0v${HEIGHT}`} stroke="#85897a" strokeWidth="2" opacity=".8" />
          <path d={`M${x + 30} 0v${HEIGHT}`} stroke="#414d44" strokeWidth="2" opacity=".9" />
          <path d={`M${x} 0v${HEIGHT}`} stroke="#dbc578" strokeWidth="2" strokeDasharray="13 15" opacity=".84" />
          <path d={`M${x - 38} 0v${HEIGHT}M${x + 38} 0v${HEIGHT}`} stroke="#e7debe" strokeWidth="2" strokeDasharray="2 10" opacity=".8" />
        </g>
      ))}
      {ROAD_Y.map((y) => (
        <g key={`horizontal-road-${y}`}>
          <rect x="0" y={y - 40} width={WIDTH} height="80" fill="#b9ae8a" opacity=".46" />
          <rect x="0" y={y - 34} width={WIDTH} height="68" fill="#58645a" />
          <path d={`M0 ${y - 27}h${WIDTH}`} stroke="#85897a" strokeWidth="2" opacity=".8" />
          <path d={`M0 ${y + 27}h${WIDTH}`} stroke="#414d44" strokeWidth="2" opacity=".9" />
          <path d={`M0 ${y}h${WIDTH}`} stroke="#dbc578" strokeWidth="2" strokeDasharray="13 15" opacity=".84" />
          <path d={`M0 ${y - 37}h${WIDTH}M0 ${y + 37}h${WIDTH}`} stroke="#e7debe" strokeWidth="2" strokeDasharray="2 10" opacity=".8" />
        </g>
      ))}
      {/* Small landscaped medians keep the Abuja avenues recognizable. */}
      {ROAD_X.map((x, xi) => ROAD_Y.map((y, yi) => (
        <g key={`median-${x}-${y}`}>
          <rect x={x - 3} y={y - 31} width="6" height="62" rx="3" fill="#758660" />
          <circle cx={x} cy={y - 21} r="3" fill="#bdc278" />
          <circle cx={x} cy={y + 20} r="3" fill="#bdc278" />
          {(xi + yi) % 2 === 0 && <path d={`M${x-17} ${y-34}h34M${x-17} ${y+34}h34`} stroke="#f2e6c2" strokeWidth="3" />}
        </g>
      )))}

      {/* District names and street-side detail. */}
      <text x="181" y="56" className="district-title">Jabi</text>
      <text x="181" y="70" className="district-note">LAKE ROAD · BYPASS</text>
      <Lake />
      <text x="704" y="55" className="district-title">Maitama</text>
      <text x="704" y="70" className="district-note">QUIET CRESCENTS</text>
      <text x="965" y="57" className="district-title">Maitama</text>
      <text x="965" y="72" className="district-note">AMINU KANO CRESCENT</text>
      <text x="185" y="160" className="district-title">Utako</text>
      <text x="185" y="174" className="district-note">BUSY BYPASS · MOTOR PARK</text>
      <g transform="translate(296 235)">
        <rect x="-39" y="-21" width="78" height="39" rx="5" fill="#d8cda9" stroke="#9e9069" />
        <path d="M-44-21h88l-9-12h-70z" fill="#26704f" stroke="#185b40" strokeWidth="1.5" />
        <path d="M-28-21v-10m18 10v-10m18 10v-10" stroke="#e6b750" strokeWidth="4" />
        <rect x="-30" y="-13" width="17" height="21" rx="2" fill="#9bb5a0" />
        <rect x="9" y="-13" width="17" height="21" rx="2" fill="#9bb5a0" />
        <text x="0" y="31" textAnchor="middle" className="place-label">UTAKO MOTOR PARK</text>
      </g>
      <text x="460" y="157" className="district-note">CBD NORTH · UNITY FOUNTAIN</text>
      <text x="687" y="159" className="district-title">Wuse</text>
      <text x="687" y="174" className="district-note">ZONE 4 · AMINU KANO</text>
      <Market x={793} y={228} />
      <text x="949" y="158" className="district-note">MAITAMA HILL ROAD</text>
      <text x="1188" y="159" className="district-note" transform="rotate(90 1188 159)">JABI LAKE ROAD</text>
      <text x="178" y="343" className="district-note">WUSE 2 · BANEX PLAZA</text>
      <text x="417" y="343" className="district-title">Central Area</text>
      <text x="417" y="358" className="district-note">THREE ARMS ZONE</text>
      <Mosque x={522} y={406} />
      <text x="704" y="344" className="district-note">MILLENNIUM PARK</text>
      <g>
        <path d="M701 385q48-29 101-8t49 72q-30 19-69 9-48-12-81 8-25-28 0-81z" fill="#b4c89a" stroke="#91aa7f" strokeWidth="2" />
        <path d="M706 418q46-18 68 1t67 1m-128 17q48-18 72 1t55 0" fill="none" stroke="#809e72" strokeWidth="3" strokeDasharray="7 6" />
        <Tree x={716} y={392} scale={.75} /><Tree x={828} y={439} scale={.78} /><Tree x={745} y={455} scale={.65} />
        <text x="773" y="483" textAnchor="middle" className="park-label">MILLENNIUM PARK</text>
      </g>
      <text x="952" y="344" className="district-title">Asokoro</text>
      <AsoRock x={1064} y={411} />
      <text x="185" y="523" className="district-note">WUSE 2 · CITY GATE</text>
      <text x="416" y="523" className="district-note">CENTRAL AREA · CBD</text>
      <text x="702" y="523" className="district-title">Central Area</text>
      <text x="702" y="538" className="district-note">NATIONAL ASSEMBLY</text>
      <NationalAssembly x={770} y={596} />
      <text x="946" y="523" className="district-note">ASOKORO · HILL VIEW</text>
      <text x="185" y="703" className="district-title">Garki</text>
      <text x="185" y="718" className="district-note">AREA 10 · MODEL MARKET</text>
      <g transform="translate(294 775)">
        <rect x="-52" y="-23" width="104" height="42" rx="4" fill="#ddc99a" stroke="#a48f62" />
        <path d="M-56-23h112v-9h-112z" fill="#ad5d3d" />
        {[-34,-12,10,32].map((cx) => <g key={cx}><path d={`M${cx} -31v-13`} stroke="#5e7555" strokeWidth="2" /><path d={`M${cx-7} -44h14l5 13h-24z`} fill="#e5b64b" stroke="#976e30" /></g>)}
        <rect x="-43" y="-15" width="20" height="27" fill="#98b19a" /><rect x="-9" y="-15" width="20" height="27" fill="#9ab49d" /><rect x="25" y="-15" width="20" height="27" fill="#98b19a" />
        <text x="0" y="34" textAnchor="middle" className="place-label">GARKI MODEL MARKET</text>
      </g>
      <text x="700" y="703" className="district-note">GARKI AREA 2 · CIVIC QUARTER</text>
      <text x="952" y="702" className="district-title">Asokoro</text>
      <text x="952" y="717" className="district-note">DIPLOMATIC DISTRICT</text>
      <text x="183" y="883" className="district-note">GARKI · AREA 1</text>
      <text x="414" y="883" className="district-note">SOUTHERN PARKWAY</text>
      <text x="702" y="883" className="district-note">NATIONAL STADIUM ROAD</text>
      <text x="949" y="883" className="district-note">ASOKORO · OUTER RING</text>
      {parcelRows.slice(0, 3).map((y, i) => (
        <g key={`street-mark-${y}`} opacity=".82">
          <Tree x={181 + i * 21} y={y + 96} scale={.45} />
          <Tree x={344 + i * 15} y={y + 88} scale={.42} />
        </g>
      ))}

      {/* Road-name signs and crossings. */}
      {[
        { x: 296, y: 296, text: 'AHMADU BELLO WAY' },
        { x: 773, y: 476, text: 'SHEHU SHAGARI WAY' },
        { x: 1020, y: 656, text: 'ASO DRIVE' },
      ].map((sign) => (
        <g key={sign.text} transform={`translate(${sign.x} ${sign.y})`}>
          <rect x="-78" y="-12" width="156" height="24" rx="5" fill="#1e6749" stroke="#f2d079" strokeWidth="1.5" />
          <rect x="-72" y="-7" width="144" height="14" rx="2" fill="none" stroke="#d9b34d" strokeWidth=".8" />
          <text y="3" textAnchor="middle" className="sign-text">{sign.text}</text>
        </g>
      ))}
      {ROAD_X.map((x) => ROAD_Y.map((y) => (
        <g key={`crossing-${x}-${y}`} opacity=".86">
          {[-1,1].map((side) => <g key={side}>
            {Array.from({length: 5}, (_, n) => <rect key={`v-${n}`} x={x + side * 22 - 3} y={y - 28 + n * 11} width="6" height="7" rx="1" fill="#e7dfc5" />)}
            {Array.from({length: 5}, (_, n) => <rect key={`h-${n}`} x={x - 28 + n * 11} y={y + side * 20 - 3} width="7" height="6" rx="1" fill="#e7dfc5" />)}
          </g>)}
        </g>
      )))}

      {/* Route glow follows the orthogonal avenues from pickup to drop-off. */}
      <path d="M640 300H896V840H640" fill="none" stroke="#f0c867" strokeWidth="16" strokeDasharray="3 17" strokeLinecap="round" opacity=".3" />
      <path d="M640 300H896V840H640" fill="none" stroke="#ffe59c" strokeWidth="4" strokeDasharray="3 17" strokeLinecap="round" opacity=".94" />
      <g transform="translate(768 300)">
        <rect x="-85" y="-13" width="170" height="25" rx="6" fill="#216749" stroke="#f0cc71" strokeWidth="1.5" />
        <text y="3.3" textAnchor="middle" className="sign-text">WUSE → GARKI · 12.4 KM</text>
      </g>

      {/* A few stop badges mark the full five-trip geography. */}
      <StopWaypoint x={128} y={300} code="W2" name="Wuse 2" align="right" />
      <StopWaypoint x={640} y={480} code="CA" name="Central" align="right" />
      <Passenger x={896} y={300} label="Wuse" />
      <Destination x={640} y={840} label="Garki" />
      <Taxi x={640} y={300} heading="right" />

      {/* Everyday traffic; cars move along multiple avenues. */}
      <MiniCar x={100} y={272} color="#c26a48" movement="east" />
      <MiniCar x={329} y={314} color="#e2b64d" movement="west" delay="delay-a" />
      <MiniCar x={588} y={468} color="#467b5c" movement="east" delay="delay-b" />
      <MiniCar x={936} y={648} color="#c25f43" movement="west" />
      <MiniCar x={102} y={828} color="#d9cfaa" movement="east" delay="delay-a" />
      <MiniCar x={370} y={109} color="#bd694c" movement="south" />
      <MiniCar x={624} y={608} color="#d8b54f" movement="south" delay="delay-b" />
      <MiniCar x={1136} y={40} color="#548162" movement="south" delay="delay-a" />
    </>
  );
}

export function ExpandedCityTaxi() {
  const [pressed, setPressed] = useState<Direction | null>(null);

  return (
    <main className="abuja-expanded">
      <div className="game-frame">
        <header className="game-header">
          <div className="brand-lockup">
            <div className="brand-stamp" aria-hidden="true"><CarFront strokeWidth={2.1} /></div>
            <div>
              <div className="brand-name">Abuja City Taxi</div>
              <div className="brand-place">Everyday rides · Federal Capital Territory</div>
            </div>
          </div>
          <div className="shift-chip"><i aria-hidden="true" /><span className="chip-word">ON THE ROAD</span><span>SHIFT&nbsp; 00:00</span></div>
        </header>

        <section className="hero-row" aria-label="Current trip">
          <div>
            <div className="eyebrow"><MapPinned size={12} /> Abuja · Nigeria</div>
            <h1>Wuse <span>to Garki.</span></h1>
            <p className="hero-sub">Your first fare is waiting. Find the rider, then follow the avenues south.</p>
          </div>
          <div className="trip-chip"><strong>TRIP 1 / 5</strong><span>·</span><span>Pickup in Wuse</span></div>
        </section>

        <section className="map-shell" aria-label="Expanded Abuja city map">
          <div className="map-overline">
            <div className="map-overline-left">
              <NigeriaFlag />
              <span className="map-meta">ABUJA · FCT</span>
              <span className="map-meta">/</span>
              <span className="map-meta">CITY DRIVE</span>
            </div>
            <div className="map-overline-right">
              <span className="map-live">LIVE TRAFFIC</span>
              <span className="map-coordinate">WUSE&nbsp; → &nbsp;GARKI</span>
            </div>
          </div>
          <div className="map-viewport">
            <svg className="city-map" viewBox={`0 0 ${WIDTH} ${HEIGHT}`} role="img" aria-label="Expanded Abuja map with Wuse pickup, Garki destination, Jabi Lake, Aso Rock, National Mosque, Wuse Market, Millennium Park and National Assembly">
              <MapArt />
            </svg>
          </div>
          <div className="map-bottomline">
            <div className="legend">
              <span className="legend-item"><i className="legend-dot" /> Your taxi</span>
              <span className="legend-item"><i className="legend-dot passenger" /> Passenger pickup</span>
              <span className="legend-item"><i className="legend-dot destination" /> Destination</span>
            </div>
            <span className="map-attribution">WUSE · CENTRAL AREA · GARKI</span>
          </div>
        </section>

        <section className="below-map" aria-label="Shift details and driving controls">
          <section className="panel">
            <div className="panel-heading">
              <h2>Take the wheel</h2>
              <span className="panel-kicker">DRIVE</span>
            </div>
            <div className="drive-content">
              <div className="drive-copy">
                <p>Hold a direction to roll through town. Pick up in Wuse, then make the Garki drop.</p>
                <div className="key-cluster" aria-label="Keyboard controls">
                  {['W', 'A', 'S', 'D'].map((key) => <span key={key} className="keycap">{key}</span>)}
                  <span className="keycap or">or</span>
                  <span className="keycap">← ↑ ↓ →</span>
                </div>
              </div>
              <div className="pad-wrap">
                <div className="dpad" aria-label="Tappable mobile directional controls">
                  {directions.map(({ direction, Icon, label }) => (
                    <button
                      key={direction}
                      className={`direction-key ${direction}${pressed === direction ? ' is-pressed' : ''}`}
                      aria-label={`Drive ${label.toLowerCase()}`}
                      aria-keyshortcuts={direction === 'up' ? 'ArrowUp W' : direction === 'down' ? 'ArrowDown S' : direction === 'left' ? 'ArrowLeft A' : 'ArrowRight D'}
                      onPointerDown={(event) => { event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); setPressed(direction); }}
                      onPointerUp={() => setPressed(null)}
                      onPointerCancel={() => setPressed(null)}
                      onLostPointerCapture={() => setPressed(null)}
                    >
                      <Icon size={16} strokeWidth={2.7} />
                    </button>
                  ))}
                </div>
                <p className="drive-hint">TAP + HOLD TO DRIVE</p>
              </div>
            </div>
          </section>

          <section className="panel">
            <div className="panel-heading">
              <h2>Shift ledger</h2>
              <span className="panel-kicker">5 FARES · ₦24,000 EACH</span>
            </div>
            <div className="shift-content">
              <div className="shift-summary">
                <div className="summary-stat">
                  <span className="summary-label">Current fare</span>
                  <strong className="summary-value">₦0</strong>
                </div>
                <div className="summary-stat">
                  <span className="summary-label">Shift clock</span>
                  <strong className="summary-value"><Clock3 size={12} style={{ verticalAlign: '-1px', marginRight: 3 }} />00:00</strong>
                </div>
                <div className="summary-stat total">
                  <span className="summary-label">All 5 fares</span>
                  <strong className="summary-value"><WalletCards size={12} style={{ verticalAlign: '-1px', marginRight: 3 }} />₦120,000</strong>
                </div>
              </div>
              <div className="trip-ledger" aria-label="Five paid trips in this shift">
                {trips.map((trip, index) => (
                  <div key={`${trip.from}-${trip.to}-${index}`} className={`ledger-row${index === 0 ? ' current' : ''}`}>
                    <span className="ledger-number">0{index + 1}</span>
                    <span className="ledger-route"><span>{trip.from}</span><ArrowRight size={11} /><span>{trip.to}</span></span>
                    <span className="ledger-status">{index === 0 ? 'NOW · 1/5' : 'NEXT UP'}</span>
                    <strong className="ledger-fare">₦24,000</strong>
                  </div>
                ))}
              </div>
              <p className="ledger-note">Five-stop shift plan · Preview starts before the first paid drop-off.</p>
            </div>
          </section>
        </section>
        <div className="sr-only"><Clock3 /> Sample game screen, trip one of five. Current fare zero naira.</div>
      </div>
    </main>
  );
}
