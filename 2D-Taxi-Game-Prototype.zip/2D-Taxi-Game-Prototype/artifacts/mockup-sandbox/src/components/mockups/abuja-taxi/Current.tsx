import './_group.css';

const GAME_WIDTH = 1000;
const GAME_HEIGHT = 760;
const ROAD_X = [160, 500, 840] as const;
const ROAD_Y = [140, 380, 620] as const;

type Stop = { name: string; position: { x: number; y: number } };

function NigeriaFlag() {
  return (
    <svg className="nigeria-flag" viewBox="0 0 18 12" role="img" aria-label="Nigerian flag">
      <rect width="18" height="12" rx="1" fill="#f9f5e8" />
      <path d="M0 1a1 1 0 0 1 1-1h5v12H1a1 1 0 0 1-1-1zM12 0h5a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-5z" fill="#087443" />
      <rect x=".5" y=".5" width="17" height="11" rx=".7" fill="none" stroke="#d9cfb6" />
    </svg>
  );
}

function TaxiMarker({ x, y, heading }: { x: number; y: number; heading: 'up' | 'down' | 'left' | 'right' }) {
  const rotation = { up: 0, right: 90, down: 180, left: 270 }[heading];
  return (
    <g transform={`translate(${x} ${y}) rotate(${rotation})`} data-testid="marker-taxi">
      <ellipse cx="0" cy="3" rx="21" ry="14" fill="#202b26" opacity=".28" />
      <rect x="-18" y="-27" width="36" height="54" rx="11" fill="#e4b642" stroke="#fff2cb" strokeWidth="3" />
      <rect x="-12" y="-16" width="24" height="15" rx="5" fill="#b8d1c3" stroke="#286449" strokeWidth="1.5" />
      <rect x="-12" y="6" width="24" height="11" rx="4" fill="#2b684b" />
      <rect x="-20" y="-16" width="4" height="10" rx="2" fill="#35463e" />
      <rect x="16" y="-16" width="4" height="10" rx="2" fill="#35463e" />
      <rect x="-20" y="12" width="4" height="10" rx="2" fill="#35463e" />
      <rect x="16" y="12" width="4" height="10" rx="2" fill="#35463e" />
      <path d="M-7 -22h14" stroke="#fff0bd" strokeWidth="2" strokeLinecap="round" />
      <path d="M-17 2h34" stroke="#fff0bd" strokeWidth="2" opacity=".85" />
      <rect x="-10" y="-6" width="20" height="6" rx="2.5" fill="#f7efd8" stroke="#286449" strokeWidth="1" />
      <text x="0" y="-1.3" textAnchor="middle" fontFamily="Space Mono" fontWeight="700" fontSize="4" fill="#28583f">TAXI</text>
      <g transform="translate(0 21)" aria-label="Nigerian flag taxi livery">
        <rect x="-8" y="-3" width="16" height="6" rx="1" fill="#fff8e6" stroke="#286449" strokeWidth=".8" />
        <rect x="-6.5" y="-1.8" width="4" height="3.6" fill="#087443" />
        <rect x="-2.5" y="-1.8" width="5" height="3.6" fill="#fff8e6" />
        <rect x="2.5" y="-1.8" width="4" height="3.6" fill="#087443" />
      </g>
    </g>
  );
}

function PersonMarker({ x, y, pickupName }: { x: number; y: number; pickupName: string }) {
  const label = `PICKUP · ${pickupName.toUpperCase()}`;
  const labelWidth = Math.max(90, label.length * 4.8 + 14);
  return (
    <g transform={`translate(${x} ${y})`} data-testid="marker-passenger" aria-label={`Passenger waiting at the ${pickupName} pickup`}>
      <circle r="31" fill="#e7b958" opacity=".3" />
      <circle r="22" fill="#f7f2dc" stroke="#286449" strokeWidth="4" />
      <circle cy="-4" r="5.4" fill="#dca677" />
      <path d="M-9 11c.8-7 4-10 9-10s8.2 3 9 10" fill="#286449" />
      <rect x="-2" y="-31" width="4" height="9" rx="2" fill="#286449" />
      <circle cy="-34" r="3.5" fill="#e7b958" />
      <g transform="translate(0 -51)">
        <rect x={-labelWidth / 2} y="-8" width={labelWidth} height="16" rx="8" fill="#28583f" stroke="#f7f2dc" strokeWidth="1" />
        <text x="0" y="2.7" textAnchor="middle" fontFamily="Space Mono" fontWeight="700" fontSize="6.5" letterSpacing=".3" fill="#fff8e7">{label}</text>
      </g>
    </g>
  );
}

function DestinationMarker({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <circle r="29" fill="#e9bd5b" opacity=".17" />
      <circle r="19" fill="#f7f2dc" stroke="#d09d34" strokeWidth="3" />
      <path d="M-8 1 0-8l8 9v8H3V3h-6v7h-5z" fill="#d09d34" />
      <path d="M0-20v-5" stroke="#d09d34" strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}

function MapDecor({ origin, destination }: { origin: Stop; destination: Stop }) {
  const start = origin.position;
  const end = destination.position;
  const routePath = start.x === end.x
    ? `M${start.x} ${start.y}V${end.y}`
    : start.y === end.y
      ? `M${start.x} ${start.y}H${end.x}`
      : start.y < end.y
        ? `M${start.x} ${start.y}H${end.x}V${end.y}`
        : `M${start.x} ${start.y}V${end.y}H${end.x}`;

  const blocks: { x: number; y: number; w: number; h: number; fill: string; name: string; kind?: 'mosque' | 'rock' | 'market' | 'station' }[] = [
    { x: 28, y: 26, w: 91, h: 72, fill: '#ddc89e', name: 'WUSE ZONE 3' },
    { x: 206, y: 26, w: 106, h: 72, fill: '#e9d7b3', name: 'WUSE 2' },
    { x: 350, y: 26, w: 106, h: 72, fill: '#d5c39d', name: 'WUSE MARKET', kind: 'market' },
    { x: 544, y: 26, w: 102, h: 72, fill: '#ead9b6', name: 'AMINU KANO CR.' },
    { x: 690, y: 26, w: 112, h: 72, fill: '#d4c79f', name: 'BANEX PLAZA' },
    { x: 879, y: 26, w: 92, h: 72, fill: '#e5d2ad', name: 'WUSE ZONE 5' },
    { x: 28, y: 181, w: 91, h: 158, fill: '#e6d7b8', name: 'AREA 11' },
    { x: 206, y: 181, w: 106, h: 158, fill: '#d6c39b', name: 'CENTRAL AREA' },
    { x: 350, y: 181, w: 106, h: 158, fill: '#e9d8b5', name: "NAT'L MOSQUE", kind: 'mosque' },
    { x: 544, y: 181, w: 102, h: 158, fill: '#d5c49f', name: 'CENTRAL CBD' },
    { x: 690, y: 181, w: 112, h: 158, fill: '#e5d5b2', name: 'MILLENNIUM PARK' },
    { x: 879, y: 181, w: 92, h: 158, fill: '#d6c49d', name: 'ASO ROCK VIEW', kind: 'rock' },
    { x: 28, y: 422, w: 91, h: 158, fill: '#d9c79f', name: 'AREA 10' },
    { x: 206, y: 422, w: 106, h: 158, fill: '#ead9b7', name: 'CENTRAL AREA' },
    { x: 350, y: 422, w: 106, h: 158, fill: '#d4c29b', name: 'CBD SOUTH' },
    { x: 544, y: 422, w: 102, h: 158, fill: '#e8d6b1', name: 'AREA 3' },
    { x: 690, y: 422, w: 112, h: 158, fill: '#d9c8a3', name: 'GARKI NORTH' },
    { x: 879, y: 422, w: 92, h: 158, fill: '#e8d7b3', name: 'GARKI VILLAGE' },
    { x: 28, y: 662, w: 91, h: 72, fill: '#e8d5b1', name: 'GARKI AREA 1' },
    { x: 206, y: 662, w: 106, h: 72, fill: '#d5c39b', name: 'GARKI MODEL MKT.' },
    { x: 350, y: 662, w: 106, h: 72, fill: '#ead9b7', name: 'GARKI AREA 10' },
    { x: 544, y: 662, w: 102, h: 72, fill: '#d3c198', name: 'GARKI AREA 2', kind: 'station' },
    { x: 690, y: 662, w: 112, h: 72, fill: '#ead7b2', name: 'GARKI DISTRICT' },
    { x: 879, y: 662, w: 92, h: 72, fill: '#d8c69e', name: 'AREA 7' },
  ];

  return (
    <>
      <rect width={GAME_WIDTH} height={GAME_HEIGHT} fill="#c9bb96" />
      {blocks.map((block, i) => (
        <g key={`${block.name}-${block.x}-${block.y}`}>
          <rect x={block.x} y={block.y} width={block.w} height={block.h} rx="12" fill={block.fill} stroke="#ae9b74" strokeWidth="1" />
          {block.kind === 'market' ? (
            <g transform={`translate(${block.x + block.w / 2} ${block.y + 39})`}>
              <rect x="-35" y="-5" width="70" height="24" rx="3" fill="#f2e7d0" stroke="#a99872" strokeWidth="1.2" />
              <rect x="-38" y="-15" width="76" height="11" rx="2" fill="#176a46" />
              <path d="M-30-15h12v11h-12zm24 0h12v11H-6zm24 0h12v11H18z" fill="#f2c45e" />
              <rect x="-26" y="0" width="18" height="13" rx="1.5" fill="#aac4b1" stroke="#6d8977" />
              <rect x="8" y="0" width="18" height="13" rx="1.5" fill="#aac4b1" stroke="#6d8977" />
              <path d="M-35-4h70" stroke="#b44936" strokeWidth="2" />
            </g>
          ) : block.kind === 'station' ? (
            <g transform={`translate(${block.x + block.w / 2} ${block.y + 34})`}>
              <path d="M-39-5h78l7 8h-92z" fill="#176a46" stroke="#e0b64f" strokeWidth="1.5" />
              <rect x="-27" y="3" width="54" height="21" rx="2" fill="#f3e8d0" stroke="#a99872" />
              <rect x="-18" y="6" width="13" height="15" rx="1" fill="#adc6b4" />
              <rect x="9" y="6" width="9" height="15" rx="1" fill="#e0b64f" stroke="#97753a" />
              <path d="M18 8h5v8h-5m0-6-4-4" fill="none" stroke="#176a46" strokeWidth="1.5" />
              <text x="0" y="-7" textAnchor="middle" fontFamily="Space Mono" fontWeight="700" fontSize="4.2" fill="#fff8e7">FILLING STATION</text>
            </g>
          ) : block.kind === 'mosque' ? (
            <g transform={`translate(${block.x + block.w / 2} ${block.y + 63})`}>
              <rect x="-32" y="-1" width="64" height="39" rx="4" fill="#e9e1cc" stroke="#a99872" strokeWidth="1.5" />
              <path d="M-20 -1c0-28 40-28 40 0" fill="#527b5d" stroke="#3f684e" strokeWidth="1.5" />
              <path d="M0-28v-13m-4 0 4-6 4 6" fill="none" stroke="#b28e43" strokeWidth="2" strokeLinecap="round" />
              <rect x="-25" y="-22" width="5" height="21" rx="2" fill="#d1bc86" />
              <rect x="20" y="-22" width="5" height="21" rx="2" fill="#d1bc86" />
              <path d="M-8 38v-18a8 8 0 0 1 16 0v18" fill="#82977a" />
            </g>
          ) : block.kind === 'rock' ? (
            <g transform={`translate(${block.x + block.w / 2} ${block.y + 79})`}>
              <path d="M-38 27-25 3-15 11 0-31 12-8 21-19 39 27Z" fill="#ae8a58" stroke="#947345" strokeWidth="1.5" />
              <path d="m-15 11 15-42 12 23" fill="none" stroke="#d8c08d" strokeWidth="2" opacity=".9" />
            </g>
          ) : i % 6 !== 0 ? (
            <rect x={block.x + 13} y={block.y + 13} width={block.w - 26} height={Math.min(28, block.h - 25)} rx="6" fill={i % 2 ? '#f2e7d0' : '#e9dfc8'} stroke="#c6b58f" />
          ) : null}
          <text x={block.x + block.w / 2} y={block.y + (block.h > 100 ? block.h - 15 : block.kind === 'market' || block.kind === 'station' ? block.h - 5 : block.h / 2 + 3)} textAnchor="middle" className="building-label">{block.name}</text>
          {block.h > 100 && block.kind !== 'mosque' && block.kind !== 'rock' && <g fill="#68845c">
            <circle cx={block.x + 17} cy={block.y + block.h - 43} r="7" />
            <circle cx={block.x + block.w - 17} cy={block.y + block.h - 43} r="7" />
            <circle cx={block.x + block.w / 2} cy={block.y + block.h - 43} r="6" />
          </g>}
        </g>
      ))}
      {ROAD_X.map((x) => <g key={`road-v-${x}`}>
        <rect x={x - 43} y="0" width="86" height={GAME_HEIGHT} fill="#9c8968" opacity=".45" />
        <rect x={x - 39} y="0" width="78" height={GAME_HEIGHT} fill="#626a63" />
        <path d={`M${x - 33} 0v${GAME_HEIGHT}`} stroke="#90948a" strokeWidth="2" />
        <path d={`M${x + 33} 0v${GAME_HEIGHT}`} stroke="#4c554f" strokeWidth="2" />
        <path d={`M${x} 0v${GAME_HEIGHT}`} stroke="#d4bd78" strokeWidth="2" strokeDasharray="11 12" opacity=".9" />
      </g>)}
      {ROAD_Y.map((y) => <g key={`road-h-${y}`}>
        <rect x="0" y={y - 41} width={GAME_WIDTH} height="82" fill="#9c8968" opacity=".45" />
        <rect x="0" y={y - 37} width={GAME_WIDTH} height="74" fill="#626a63" />
        <path d={`M0 ${y - 31}h${GAME_WIDTH}`} stroke="#90948a" strokeWidth="2" />
        <path d={`M0 ${y + 31}h${GAME_WIDTH}`} stroke="#4c554f" strokeWidth="2" />
        <path d={`M0 ${y}h${GAME_WIDTH}`} stroke="#d4bd78" strokeWidth="2" strokeDasharray="11 12" opacity=".9" />
      </g>)}
      {ROAD_X.map((x) => ROAD_Y.map((y) => <g key={`crossing-${x}-${y}`} opacity=".9">
        {[-1, 1].map((side) => <g key={side}>
          {Array.from({ length: 5 }, (_, n) => <rect key={n} x={x + side * 24 - 4} y={y - 31 + n * 12} width="8" height="7" rx="1" fill="#e5ddc5" />)}
          {Array.from({ length: 5 }, (_, n) => <rect key={`h-${n}`} x={x - 31 + n * 12} y={y + side * 23 - 4} width="7" height="8" rx="1" fill="#e5ddc5" />)}
        </g>)}
      </g>))}
      <path d={routePath} fill="none" stroke="#f0c866" strokeWidth="11" strokeDasharray="3 14" strokeLinecap="round" opacity=".42" />
      <path d={routePath} fill="none" stroke="#ffe39a" strokeWidth="3" strokeDasharray="3 14" strokeLinecap="round" opacity=".9" />
      <g transform="translate(500 119)">
        <rect x="-164" y="-13" width="328" height="25" rx="5" fill="#176a46" stroke="#f7f2dc" strokeWidth="2" />
        <rect x="-158" y="-8" width="316" height="15" rx="2" fill="none" stroke="#e5bd5e" strokeWidth="1" />
        <text x="0" y="3.5" textAnchor="middle" className="road-sign-label">WUSE 2 → CENTRAL AREA → GARKI</text>
      </g>
      <g opacity=".8">
        <circle cx="74" cy="54" r="13" fill="#5f8059" /><circle cx="74" cy="54" r="8" fill="#9cae70" />
        <circle cx="925" cy="700" r="13" fill="#5f8059" /><circle cx="925" cy="700" r="8" fill="#9cae70" />
      </g>
    </>
  );
}

export function Current() {
  const wuse = { name: 'Wuse', position: { x: 840, y: 140 } };
  const garki = { name: 'Garki', position: { x: 500, y: 620 } };

  return (
    <main className="current-map">
      <section className="map-card">
        <div className="map-topline">
          <div className="map-label"><NigeriaFlag /> ABUJA · FCT</div>
          <div className="map-coordinate">FCT&nbsp; WUSE&nbsp; →&nbsp; GARKI</div>
        </div>
        <div className="map-viewport">
          <svg className="city-map" viewBox={`0 0 ${GAME_WIDTH} ${GAME_HEIGHT}`} role="img" aria-label="Current Abuja taxi map with Wuse pickup and Garki drop-off">
            <MapDecor origin={wuse} destination={garki} />
            <PersonMarker x={wuse.position.x} y={wuse.position.y} pickupName={wuse.name} />
            <DestinationMarker x={garki.position.x} y={garki.position.y} />
            <TaxiMarker x={160} y={140} heading="right" />
          </svg>
        </div>
        <div className="map-footer">
          <span>● Your Abuja taxi&nbsp;&nbsp; ● Passenger&nbsp;&nbsp; ● Drop-off</span>
          <span className="map-note">ABUJA, NIGERIA · FCT</span>
        </div>
      </section>
    </main>
  );
}
